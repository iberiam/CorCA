/*
    This file is part of Zervit
    Copyright (C) 2009  Sebastian Fernandez

    Zervit is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Zervit is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <libz/libz.h>

extern char *Z_DIR_HEAD;
extern char *Z_DIR_HEAD2;
extern char *Z_DIR_TABLE_TOP;
extern char *Z_DIR_TD1;
extern char *Z_DIR_TD12;
extern char *Z_DIR_TD2;
extern char *Z_DIR_TD3;
extern char *Z_DIR_TD4;
extern char *Z_DIR_TABLE_FOOT;
extern char *Z_DIR_FOOT;

void ld_add_iconart(struct http_data *msgs, char *file);

void http_list_dir(struct http_answer *answ, struct http_data *msgs){
	struct dir_entry *l_dirs[MAX_DIR_LIST];
	int i;
	char tmp[1024];
	char tmpopen[1024];
#ifdef _WIN32
    #define D_NAME f.cFileName
    #define D_ISDIR (f.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
    WIN32_FIND_DATA f;
    HANDLE h;
#elif defined(linux)
    #define D_ISDIR ent->d_type == DT_DIR
    #define D_NAME ent->d_name
	DIR *dir;
	struct dirent *ent;
#endif    
    if(msgs->file[0] == '\0')
        strncat(msgs->file,".",1);
    r_strip(msgs->file,DIR_CH_S);
    strncat(msgs->file,DIR_CH_S,strlen(DIR_CH_S));
#ifdef _WIN32
    strncat(msgs->file,"*",strlen("*"));
    h = FindFirstFile(msgs->file, &f);
    r_strip(msgs->file,"*");
    if(h != INVALID_HANDLE_VALUE)
#elif defined(linux)
	dir = opendir(msgs->file);
	if(dir)
#endif
	{
		answ->status = 200;
		answ->content_type = TXT_HTML;
		answ->size = 0;
		http_send_head(answ, msgs);
		send_text(msgs->sck,Z_DIR_HEAD);
		send_text(msgs->sck,msgs->file);
		send_text(msgs->sck,Z_DIR_HEAD2);
		send_text(msgs->sck,Z_DIR_TABLE_TOP);
#ifdef _WIN32
        do
#elif defined(linux)
        while((ent = readdir(dir)) != NULL)
#endif		
		{
			send_text(msgs->sck,Z_DIR_TD1);
			strcpy(tmpopen, msgs->file);
			strncat(tmpopen,D_NAME,200);
			//strcpy(tmp, msgs->file);
			tmp[0]='\0';
			strncat(tmp,D_NAME,200);
			if(strcmp("..",D_NAME) == 0){
				//r_strip(tmp,ent->d_name);
				//bck_file(tmp);
				send_text(msgs->sck,"/folder32");
				send_text(msgs->sck,Z_DIR_TD12);
				send_text(msgs->sck,D_NAME);
			}
			else if((D_ISDIR) || (get_file_size(tmpopen)<0)){
				strncat(D_NAME,"/",2);
				send_text(msgs->sck,"/folder32");
				send_text(msgs->sck,Z_DIR_TD12);
				send_text(msgs->sck,D_NAME);
			}
			else{
				ld_add_iconart(msgs,D_NAME);
				send_text(msgs->sck,Z_DIR_TD12);
				send_text(msgs->sck,tmp);
			}
			send_text(msgs->sck,Z_DIR_TD2);
			send_text(msgs->sck,D_NAME);
			send_text(msgs->sck,Z_DIR_TD3);
			if((D_ISDIR) || (get_file_size(tmpopen)<0)){
				send_text(msgs->sck,"[DIR]");
			}
			else{
				itoa_t(get_file_size(tmpopen),tmp);
				send_text(msgs->sck,tmp);
			}
			send_text(msgs->sck,Z_DIR_TD4);
			ops_debug("%s\n",D_NAME);
#ifdef _WIN32
        } while(FindNextFile(h, &f));
#elif defined(linux)
        }
#endif
		send_text(msgs->sck,Z_DIR_TABLE_FOOT);
		send_text(msgs->sck,Z_DIR_FOOT);
#ifdef _WIN32
#elif  defined(linux)
		closedir(dir);
#endif
	}
	else
	{
		ops_debug("Cant open dir\n");
		answ->status = 404;
		http_error(answ, msgs);
	}
	return;
}

void ld_add_iconart(struct http_data *msgs, char *file){
	int ext;
	if(strcmp(file,ZERVIT_NAME)==0){
		send_text(msgs->sck,"/zervit32");
		return;
	}
	ext = get_filetype(file);
	switch(ext){
        case Z_PPT:
            send_text(msgs->sck, "/ppt32");
            break;
        case Z_ZIP:
            send_text(msgs->sck, "/zip32");
            break;
		case Z_IMG:
			send_text(msgs->sck, "/img32");
			break;
		case Z_TXT:
			send_text(msgs->sck, "/txt32");
			break;
		case Z_PDF:
			send_text(msgs->sck, "/pdf32");
			break;
		case Z_DOC:
			send_text(msgs->sck, "/doc32");
			break;
		case Z_XLS:
			send_text(msgs->sck, "/xls32");
			break;
		case Z_EXE:
			send_text(msgs->sck, "/exe32");
			break;
		case Z_VIDEO:
			send_text(msgs->sck, "/video32");
			break;
		case Z_MUSIC:
			send_text(msgs->sck, "/sound32");
			break;
		case Z_DATA:
			send_text(msgs->sck, "/data32");
			break;
		case Z_FOLDER:	
			send_text(msgs->sck, "/folder32");
			break;
		case Z_UNKNOWN:
			send_text(msgs->sck, "/data32");
			break;
	}
	return;
}
