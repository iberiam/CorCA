/*
    This file is part of Zervit
    Copyright (C) 2009  Sebastian Fernandez

    Zervit is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Zervit is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <libz/libz.h>
#include <stdlib.h>
#include <stdio.h>
#include <opt.h>
#include <config.h>

extern struct inzervit zart[];

struct inzervit *zin[] = {zart, 0};


int file_inzervit(char * file){	
	int i, j;
	
	if(file==0 || *file==0)
		return 0;
	for(j=0; zin[j]!=0; j++){
		for(i=0; ;i++){
			if(zin[j][i].name == 0)
				break;
			else if(strcmp(zin[j][i].name,file)==0)
				return 1;
		}
	}
	return 0;
}

void serve_inzervit(struct http_data *msgs, struct http_answer *answer){
	int i, j, found=0;
	
	for(j=0; zin[j]!=0; j++){
		for(i=0; ;i++){
			if(zin[j][i].name == 0)
				break;
			else if(strcmp(zin[j][i].name,msgs->file)==0){
				found=1;
				break;
			}
		}
		if(found==1)
			break;
	}
	ops_debug("2: found=%i, i=%i, j=%i\n",found,i,j);
	if(zin[j]==0)
		return;
	answer->size = zin[j][i].length;
	answer->content_type = zin[j][i].type;
	answer->status = 200;
	ops_debug("length=%i, type=%i, status=%i\n",answer->size, answer->content_type,	answer->status);
    http_send_head(answer,msgs);
    
    send(msgs->sck, zin[j][i].ptr, zin[j][i].length,0);
    
    send_text(msgs->sck,"\r\n\r\n");
}
