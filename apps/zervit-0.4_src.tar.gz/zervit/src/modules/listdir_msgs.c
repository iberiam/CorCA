/*
    This file is part of Zervit
    Copyright (C) 2009  Sebastian Fernandez

    Zervit is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Zervit is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <config.h>

//Directory listing messages
char *Z_DIR_HEAD = "<html><head><title>Zervit - Dir Listing</title></head>"\
	"<body><h1>Zervit Dir Listing: ";
	
char *Z_DIR_HEAD2 = "</h1><hr />";

char *Z_DIR_TABLE_TOP = "<table><tr><th></th><th><a>Name</a></th>"\
		"<th><a>Size</a></th></tr><tr><th colspan=\"5\"><hr></th></tr>";

//char *Z_DIR_TD1 = "<tr><td valign=\"top\"><img src=\"/icons/unknown.gif\" alt=\"[   ]\"></td><td><a href=\"";
char *Z_DIR_TD1 = "<tr><td valign=\"top\"><img src=\"";

char *Z_DIR_TD12= "\" alt=\"[   ]\"></td><td><a href=\"";

char *Z_DIR_TD2 = "\">";

char *Z_DIR_TD3 = "</a></td><td align=\"right\">";

char *Z_DIR_TD4 = "</td></tr>";

char *Z_DIR_TABLE_FOOT = "<tr><th colspan=\"5\"><hr></th></tr></table>";

char *Z_DIR_FOOT = ZERVIT_FOOT "</body></html>";
