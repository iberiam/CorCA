/*
    This file is part of Zervit
    Copyright (C) 2009  Sebastian Fernandez

    Zervit is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Zervit is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <config.h>

char *Z_NOTFOUND = "<html><head><title>Zervit - 404 Not Found</title></head>"\
	"<body><h1>Not Found</h1>"\
	"<p>The requested URL was not found on this server.</p><hr>"\
	ZERVIT_FOOT\
	"</body></html>";
	
char *Z_NOTALLOWED = "<html><head><title>Zervit - 403 Unauthorized</title></head>"\
	"<body><h1>Unauthorized</h1>"\
	"<p>Ypu don't have privileges to access the requested URL on the server.</p><hr>"\
	ZERVIT_FOOT\
	"</body></html>";

char *Z_HEAD_ERROR1="HTTP/1.1 ";
char *Z_HEAD_ERROR2="\r\nServer: "ZERVIT_VERSION"\r\n"
	"X-Powered-By: Carbono\r\nConnection: close\r\nContent-Type: ";
	
char *Z_HEAD_OK="HTTP/1.1 200 OK\r\nServer: "ZERVIT_VERSION
	"\r\nX-Powered-By: Carbono\r\n"
	"Connection: close\r\nAccept-Ranges: bytes\r\nContent-Type: ";
