/*
    This file is part of Zervit
    Copyright (C) 2009  Sebastian Fernandez

    Zervit is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Zervit is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <libz/libz.h>
#include <config.h>

void http_error(struct http_answer *answ, struct http_data *msgs)
{
	answ->content_type = TXT_HTML;
	switch (answ->status){
	    case 404:
	        answ->size = strlen(Z_NOTFOUND);
	        http_send_head(answ,msgs);
	        send(msgs->sck,Z_NOTFOUND,strlen(Z_NOTFOUND),0);
	        break;
	    case 403:
	        answ->size = strlen(Z_NOTALLOWED);
	        http_send_head(answ,msgs);
	        send(msgs->sck,Z_NOTALLOWED,strlen(Z_NOTALLOWED),0);
	        break;
	    default:
	        return;
	}
	answ->size = 0;
}

void http_send_head(struct http_answer *answ, struct http_data *msgs){
    char tmp[20];
    char *HTTP_TYPE[]={"text/html","text/css","text/plain","image/jpeg","image/png",
                    "application/octet-stream"};
    if(answ->status==200){ //OK header ;)
        send(msgs->sck,Z_HEAD_OK,strlen(Z_HEAD_OK),0);
    }
    else{ //Error header
        itoa_t(answ->status,tmp);
        send_text(msgs->sck,Z_HEAD_ERROR1);
        send_text(msgs->sck,tmp);
        send_text(msgs->sck,Z_HEAD_ERROR2);
    }
    send(msgs->sck,HTTP_TYPE[answ->content_type],
            strlen(HTTP_TYPE[answ->content_type]),0);
	//For dynamic content we dont send size
	if(answ->size != 0){
    	send(msgs->sck,"\r\nContent-Length: ",
    				strlen("\r\nContent-Length: "),0);
    	itoa_t(answ->size,tmp);
    	send(msgs->sck,tmp,strlen(tmp),0);
    }
    //Finish header
    send(msgs->sck,"\r\n\r\n",strlen("\r\n\r\n"),0);
       
}
