/*
    This file is part of Zervit
    Copyright (C) 2009  Sebastian Fernandez

    Zervit is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Zervit is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <libz/libz.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

struct ext_db extensions[] = {
	{"ico",		Z_IMG},
	{"jpg",		Z_IMG},
	{"jpeg",	Z_IMG},
	{"png",		Z_IMG},
	{"htm",		Z_TXT},
	{"html",	Z_TXT},
	{"css",		Z_TXT},
	{"php",		Z_TXT},
	{"txt",		Z_TXT},
	{"rtf",		Z_TXT},
	{"pdf",		Z_PDF},
	{"exe",		Z_EXE},
	{"msi",		Z_EXE},
	{"out",		Z_EXE},
	{"dll",		Z_EXE},
	{"com",		Z_EXE},
	{"so",		Z_EXE},
	{"mov",		Z_VIDEO},
	{"mp4",		Z_VIDEO},
	{"swf",		Z_VIDEO},
	{"flv",		Z_VIDEO},
	{"divx",	Z_VIDEO},
	{"wav",		Z_MUSIC},
	{"mp3",		Z_MUSIC},
	{"ogg",		Z_MUSIC},
	{"xls",		Z_XLS},
	{"xlsx",	Z_XLS},
	{"doc",		Z_DOC},
	{"docx",	Z_DOC},
	{"docm",	Z_DOC},
	{"ppt",		Z_PPT},
	{"pptx",	Z_PPT},
	{"zip",     Z_ZIP},
	/* Future implementation */

	/* End table */
	{0,			0}
};

int get_filetype(char *file)
{
	int i, j;
	char ext[10];
	j= i= strlen(file);
	while(file[i]!='.' && i > (j - 9))
		i--;
	if(i < (j - 9))
		return Z_UNKNOWN;
	strcpy(ext,&file[i+1]);
	str_tolower(ext);
	ops_debug("Extension: %s\n",ext);
	for(i=0; ;i++){
		if(extensions[i].ext==0)
			return Z_UNKNOWN;
		else if(strcmp(extensions[i].ext,ext)==0)
			return extensions[i].value;
	}
/*
	if(i < strlen(file)-9)
		return UNKNOWN;
	strcpy(ext,&file[i]);
	ops_debug("Extension: %s\n",ext);
	if(strcmp(ext,".html")==0)
		    return TXT;
	else if(strcmp(ext,".htm")==0)
			return TXT
	else if(strcmp(ext,".php")==0)
			return TXT
	else if(strcmp(ext,".css")==0)
			return TXT
	else if(strcmp(ext,".txt")==0)
			return TXT
	else if(strcmp(ext,".png")==0)
			return IMG
	else if(strcmp(ext,".jpg")==0)
			return IMG
	else if(strcmp(ext,".jpeg")==0)
			return IMG
    else if(strcmp(ext,".ico")==0)
			return IMG
	else if(strcmp(ext,".pdf")==0)
			return PDF
	else
		    return UNKNOWN;
*/
}

int get_extension(char *file)
{
	int i, j;
	char ext[10];
	j= i= strlen(file);
	while(file[i]!='.' && i > (j - 9))
		i--;
	if(i < (j - 9))
		return APP_OCT_STREAM;
	strcpy(ext,&file[i]);
	str_tolower(ext);
	ops_debug("Extension: %s\n",ext);
	if(strcmp(ext,".html")==0)
		    return TXT_HTML;
	else if(strcmp(ext,".htm")==0)
			return TXT_HTML;
	else if(strcmp(ext,".php")==0)
			return TXT_HTML;
	else if(strcmp(ext,".png")==0)
			return IMG_PNG;
	else if(strcmp(ext,".css")==0)
			return TXT_CSS;
	else if(strcmp(ext,".jpg")==0)
			return IMG_JPEG;
	else if(strcmp(ext,".jpeg")==0)
			return IMG_JPEG;
    else if(strcmp(ext,".txt")==0)
			return TXT_PLAIN;			
	else
		    return APP_OCT_STREAM;
}

long get_file_size(char *file){
	FILE *fp;
	long filelen;
	fp = fopen(file,"rb");
	if(fp != NULL){
		fseek (fp , 0 , SEEK_END);
		filelen = ftell (fp);
		fclose(fp);
		return filelen;
	}
	return -1;
}

/* Malloced return FIXME */
char *get_word(struct http_data *msgs)
{
	int state=INITIAL, ptr1, ptr2;
	char *word;
	while(1){
		switch(msgs->data[msgs->ptr]){
		case ' ':
		case '\t':
		case '\n':
		case ':':
			state=(state==INITIAL)?(INITIAL):(END);
			break;
		default:
			state=(state==INITIAL)?(FIRST):(CHAIN);
			break;
		}
		if(state==FIRST)
			ptr1=msgs->ptr;
		else if(state==END){
			ptr2=msgs->ptr;
			break;
		}
		msgs->ptr++;
	}
	word=(char *)malloc(ptr2-ptr1+2);
	memcpy(word,&msgs->data[ptr1],ptr2-ptr1);
	word[ptr2-ptr1]='\0';
	return word;
}

/* Malloced return FIXME */
char *get_line(struct http_data *msgs)
{
	int ptr1, ptr2;
	char *line;
	ptr1=msgs->ptr;
	while(msgs->data[msgs->ptr]!='\r')
		msgs->ptr++;
	ptr2=msgs->ptr;
	line=(char *)malloc(ptr2-ptr1+2);
	memcpy(line,&msgs->data[ptr1],ptr2-ptr1);
	line[ptr2-ptr1]='\0';
	return line;
}

void goto_newline(struct http_data *msgs)
{
	while(msgs->data[msgs->ptr]!='\n')
		msgs->ptr++;
	msgs->ptr++;
	return;
}

void bck_file(char *str){
	int i;
	r_strip(str,DIR_CH_S);
	for(i=strlen(str);i>0;i--){
		if(str[i]==DIR_CH){
			str[i]='\0';
			return;
		}
	}
}

void http_parse_hex(char *str){
    char *tmp, num;
    int i, j;
    if(strlen(str)==0)
        return;
	tmp = (char *)malloc(strlen(str)+1);
    for(i=0,j=0;i<strlen(str);i++,j++){
        if(str[i]=='%'){
            i++;
            num=(str[i]-0x30)*0x10;
            i++;
            num+=(str[i]-0x30);
            tmp[j]=num;
        }
        else
            tmp[j]=str[i];
    }
    tmp[j]='\0';
    strcpy(str,tmp);
    free(tmp);
}

//Left strip
char *l_strip(char *str,char *what)
{
	long j,k;
	char state=FOUND;
	//Left strip.
	while(state!=N_FOUND){
		state=N_FOUND;
		for(j=0;j<strlen(what);j++){
			if(*str==what[j]){
				for(k=0;k<strlen(str);k++)
					str[k]=str[k+1];
				str[k]='\0';
				state=FOUND;
			}
		}
	}
	//Return pointer to the same modified string.
	return str;
}

//Right strip
char *r_strip(char *str,char *what)
{
	long j;
	char state=FOUND;
	while(state!=N_FOUND){
		state=N_FOUND;
		for(j=0;j<strlen(what);j++){
			if(str[strlen(str)-1]==what[j]){
				str[strlen(str)-1]='\0';
				state=FOUND;
			}
		}
	}
	//Return pointer to the same modified string.
	return str;
}

//Find first file compatible with the server.
void find_first(struct http_data *msgs)
{
	char *posible[] = {"index.htm", "index.html", "index.txt","\0"};
	int i, tmp;
	FILE *fp;
    
    msgs->file = realloc(msgs->file, strlen(msgs->file)+20);
    tmp=strlen(msgs->file);
	for(i=0;strcmp(posible[i],"\0")!=0;i++){
		strncat(msgs->file,posible[i],512);
		fp=fopen(msgs->file,"rb");
		ops_debug("before: %s\n",msgs->file);
		if(fp!=NULL){
		    fclose(fp);
			break;
		}
		msgs->file[tmp]='\0';
		ops_debug("after: %s\n",msgs->file);
	}
}

#ifdef linux
//No way that GNU libc has not the itoa function!!
//Stolen from the book "The C programming language", thank you Kernighan and Ritchie ;)
void itoa(int n, char s[])
{
    int i, sign;

    if((sign=n) < 0)  /* record sign */
        n= -n;          /* make n positive */
    i=0;
    do{       /* generate digits in reverse order */
        s[i++]=n % 10 + '0';   /* get next digit */
    }while ((n /= 10) > 0);     /* delete it */
    if (sign < 0)
        s[i++]='-';
    s[i]='\0';
    reverse(s);
}

/* reverse:  reverse string s in place */
void reverse(char s[])
{
	int c, i, j;

	for(i=0, j=strlen(s)-1; i<j; i++, j--){
		c=s[i];
		s[i]=s[j];
		s[j]=c;
	}
}

#endif

void destroy_http_data(struct http_data *msgs){
	if(msgs->file)
		free(msgs->file);
	if(msgs->user_agent)
		free(msgs->user_agent);
}

char *str_tolower(char *str)
{
int i;
for(i = 0; str[ i ]; i++)
	str[i] = tolower(str[ i ]);
return str;
}

char *str_toupper(char *str)
{
int i;
for(i = 0; str[ i ]; i++)
	str[i] = toupper(str[ i ]);
return str;
}
