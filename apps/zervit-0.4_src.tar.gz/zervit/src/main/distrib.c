/*
    This file is part of Zervit
    Copyright (C) 2009  Sebastian Fernandez

    Zervit is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Zervit is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <libz/libz.h>
#include <stdlib.h>
#include <stdio.h>
#include <opt.h>
#include <config.h>

extern zoptions_t zopts;

void parse_http(struct http_data *msgs)
{
	char *ch;
	ops_debug("%s\n",msgs->data);
	msgs->ptr=0;
	//printf("word: %s",ch);
	while(1){
		ch=get_word(msgs);
		if(strcmp(ch,"GET")==0){
			ops_debug("Get file: ");
			free(ch);
			ch=get_word(msgs);
			msgs->file = (char *)malloc(strlen(ch)+1);
			strcpy(msgs->file,ch);
			ops_debug("%s\n",msgs->file);
			free(ch);
			goto_newline(msgs);
		}
		else if(strcmp(ch,"User-Agent")==0){
			ops_debug("User-Agent:");
			free(ch);
			ch=get_line(msgs);
			msgs->user_agent = (char *)malloc(strlen(ch)+1);
			strcpy(msgs->user_agent,ch);
			ops_debug("%s\n",strip(msgs->user_agent,":- "));
			free(ch);
			goto_newline(msgs);
		}
		else {
			free(ch);
			goto_newline(msgs);
		}
		//If double line jump exit
		if(msgs->data[msgs->ptr]=='\n')
			return;
		//If string end exit
		if(msgs->data[msgs->ptr]=='\0')
			return;
	}
	return;
}

struct http_answer *gen_answer(struct http_data *msgs)
{
	struct http_answer *answer;
	long filelen, tmp_r, tmp_s;
	int i;
	char temp[1024];
	
	FILE *fp;

	answer=(struct http_answer *)malloc(sizeof(struct http_answer));

#ifdef _WIN32
	for(i=0;msgs->file[i]!='\0';i++){
		if(msgs->file[i]=='/')
			msgs->file[i]='\\';
	}
#endif
	http_parse_hex(msgs->file);
	l_strip(msgs->file,DIR_CH_S);
	if(file_inzervit(msgs->file)){
		ops_debug("file \"%s\" is in zervit\n", msgs->file);
		serve_inzervit(msgs, answer);
		answer->size = 0;
		return answer;
	}
	if(FILE_IS_DIR(msgs->file) || msgs->file[0]=='\0'){
		ops_debug("Requested file: /\n");
		ops_debug("%s\n",msgs->file);
		find_first(msgs);
	}
	//If doesnt have any index file, lets list directory
	if(FILE_IS_DIR(msgs->file) || msgs->file[0]=='\0'){
		//Teacher sorry for this :p
		list_dir:
		if((zopts.flags & Z_LIST_DIR) != Z_LIST_DIR){
			ops_debug("Listing dir not allowed\n");
			answer->status = 403;
			http_error(answer, msgs);
		}
		else if(msgs->file[0]=='\0'){
		    ops_debug("Listing base dir\n");
		    http_list_dir(answer,msgs);
		    answer->size=0;
		}
		else{
		    ops_debug("Listing directory: %s\n",msgs->file);
			http_list_dir(answer,msgs);
			answer->size=0;
		}
		return answer;
	}
	//Else open file or give 404 error
	else{
		ops_debug("\nTry to open \"%s\"\n",msgs->file);
		fp=fopen(msgs->file,"rb");
		//File doesnt exist, NOT_FOUND
		if(fp==NULL){
		    answer->status = 404;
			http_error(answer, msgs);
			answer->size = 0;
			return answer;
		}
		ops_debug("File %s found and open\n",msgs->file);
		fseek (fp , 0 , SEEK_END);
		filelen = ftell (fp);
		//Dirty but functional (in linux filelen -1 = dir)
		if(filelen == -1)
			goto list_dir;
    	ops_debug("File size: %i\n",filelen);
    	//Lets go to the start again
		fseek(fp,0,SEEK_SET);
		answer->size = filelen;
		answer->content_type = get_extension(msgs->file);
		answer->status = 200;
        http_send_head(answer,msgs);
        while(!feof(fp)){
	    	tmp_r=fread(temp,1,sizeof(temp),fp);
	    	tmp_s=send(msgs->sck,temp,tmp_r,0);
		}
		fclose(fp);
		answer->size=0;
		return answer;
	}
}
