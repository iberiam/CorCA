/*
    This file is part of Zervit
    Copyright (C) 2009  Sebastian Fernandez

    Zervit is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Zervit is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <libz/libz.h>
#include <main.h>
#include <opt.h>
#include <stdlib.h>
#include <stdio.h>
#include <config.h>
/*
#include <libz/http.h>
#include <libz/networking.h>
#include <config.h>
#include <libz/process.h>
#include <libz/ops.h>
#include <opt.h>
*/

zoptions_t	zopts;

void hnd_connection(SOCKET *sck);

void hnd_connection(SOCKET *sck)
{
	struct http_data msgs;
	struct http_answer *answer;

	memset(&msgs, 0, sizeof(struct http_data));

	msgs.sck=*sck;
	if(recv(*sck,msgs.data,sizeof(msgs.data),0)>0)
	{
		parse_http(&msgs);
		answer=gen_answer(&msgs);
		if(answer->size>0){
		    ops_debug("*Check answer*\n%s\n\nsize: %i\n\n",answer->data,answer->size);
		    send(*sck,answer->data,answer->size,0);
		}
		//free(answer->data);
		destroy_http_data(&msgs);
		free(answer);
	}
	ops_debug("\nclose socket\n");
	closesocket(*sck);
	*sck=(SOCKET)NULL;
	return;
}

int main(int argc, char *argv[])
{
	SOCKET sck;
	SOCKET clientmp, clients[MAX_CONNECTIONS]={0};
	struct sockaddr_in saListener;
	struct sockaddr_in saClient;
	socklen_t  len;
	int i;
	//New configuration system
    init_zopts(&zopts);
	if(!initialize_net())
			ops_error("Cannot Initialisize networking");
	//memset(clients,0,sizeof(SOCKET)*MAX_CONNECTIONS);
	memset(&saListener,0,sizeof(struct sockaddr_in));
	memset(&saClient,0,sizeof(struct sockaddr_in));
	saListener.sin_family      = PF_INET;
	saListener.sin_port        = htons( zopts.port );
	saListener.sin_addr.s_addr = htonl( INADDR_ANY );
	sck=socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);

	//I dont like waiting for server restart
	setsockopt(sck,SOL_SOCKET,SO_REUSEADDR,(void *)1,sizeof(1));
	if(sck==-1)
		ops_error("Error creating socket");
	if(bind( sck, (struct sockaddr*)&saListener, sizeof(struct sockaddr))==-1)
		ops_error("Error on socket bind");
	if(listen(sck,MAX_CONNECTIONS)==-1)
		ops_error("Error on socket listen");
	len = sizeof(struct sockaddr);
	for(;;){
		//Save client sck in a temp var
		clientmp = accept(sck,(struct sockaddr *)&saClient,&len);
		if(clientmp==-1)
			ops_wait("Accept error");
		//Same as listener socket
		setsockopt(clientmp,SOL_SOCKET,SO_REUSEADDR,(void *)0,sizeof(0));
		//setsockopt(clientmp,SOL_SOCKET,SO_KEEPALIVE,(void *)1,sizeof(1));
		
		//Store the client socket in array position and pass it to function
		for(i=0;i<MAX_CONNECTIONS;i++){
			if(clients[i]==(SOCKET)NULL)
				break;
		}
		if(clients[i]!=(SOCKET)NULL){
			ops_wait("All slots occupied");
			close(clientmp);
		}
		else{
			clients[i]=clientmp;
			create_thread(&clients[i],hnd_connection);
		}
	}
	return 0;
}
