/*
    This file is part of Zervit
    Copyright (C) 2009  Sebastian Fernandez

    Zervit is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Zervit is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <libz/libz.h>
#include <opt.h>
#include <config.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
/*
#include <libz/ops.h>
#include <opt.h>
*/
int get_zopt(char *message, int how){
	int integer;
	char letra;
	
	switch(how){
		case ZOPT_INTEGER:
			printf("%s: ", message);
			scanf("%i",&integer);
			return integer;
			break;
		case ZOPT_YESNO:
			while(1){
			printf("%s [Y/N]: ", message);
			fflush(stdin);
			scanf(" %c",&letra);
			switch(letra){
				case 'Y':
				case 'y':
					return 1;
				case 'N':
				case 'n':
					return 0;
				default:
					continue;
			}
			}
		default:
			return 0;
	}
	return 0;
}

void init_zopts(zoptions_t *zopts){
	//Clear the screen, only for "facha"
	clear_screen();
	printf("-----------\n%s\n-----------\n\n",ZERVIT_VERSION);
	printf("Configuration \n---------------\n");
	//Start configuration
	zopts->port = get_zopt("Port number to listen(80)",ZOPT_INTEGER);
	if(get_zopt("Accept directory listing",ZOPT_YESNO))
		zopts->flags |= Z_LIST_DIR;
	else
		zopts->flags &= ~Z_LIST_DIR;
	printf("\n[-]Zervit HTTP Server STARTED\n\n");
}
