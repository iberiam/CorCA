#ifndef OPT_H_
#define OPT_H_

#include <config.h>

#define Z_LIST_DIR	0x01
#define Z_USE_INDEX	0x02

#define ZOPT_INTEGER	0x01
#define ZOPT_YESNO		0x02

typedef struct _zoptions_t{
	int		flags;
	int		port;
}zoptions_t;

//Ugly clear screen
#ifdef _WIN32
	#define clear_screen() system("cls")

#elif defined(linux)
	#define clear_screen() system("clear")
#endif

int get_zopt(char *message, int how);
void init_zopts(zoptions_t *zopts);

#endif
