/*
    This file is part of Zervit
    Copyright (C) 2009  Sebastian Fernandez

    Zervit is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Zervit is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef _LIBZ_H_
#define _LIBZ_H_

/* Windows */
#ifdef _WIN32
#include <winsock2.h>
#include <Ws2def.h>
#include <windows.h>

#define socklen_t int

#define DIR_CH_S "\\"
#define DIR_CH '\\'
#define CH_IS_DIR(s) s=='\\'

#define itoa_t(a,b) itoa(a,b,10)
/* ----------------- */

/* Linux */
#elif defined(linux)
#include <pthread.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <dirent.h>
#include <unistd.h>

typedef int SOCKET;
#define closesocket(s) close(s)

#define DIR_CH_S "/"
#define DIR_CH '/'
#define CH_IS_DIR(s) s=='/'

#define itoa_t(a,b) itoa(a,b)
void itoa(int ,char s[]);
void reverse(char s[]);
void itoa_t(int num,char *buf);

/* ----------------- */
#endif

/* CONFIGURATION FILE */
#include <config.h>

/* Global Includes, at least as possible */
#include <string.h>

/* Defines for all platforms */
#define FILE_IS_DIR(s) s[strlen(s)-1]==DIR_CH

#define itoc(n) n+48
#define Z_START_NMSG 9

#define strip(msgs,what) l_strip(r_strip(msgs,what),what)
#define send_text(sock,text)	send(sock,text,strlen(text),0)
/* ----------------- */

/* Messages */
extern char *Z_NOTFOUND;
extern char *Z_NOTALLOWED;
extern char *Z_HEAD_ERROR1;
extern char *Z_HEAD_ERROR2;
extern char *Z_HEAD_OK;

/* ----------------- */


/* Values and structs */
//Values for misc.c
enum{
	INITIAL=0,FIRST,CHAIN,END,FOUND,N_FOUND
};

//File extension
enum{
	TXT_HTML=0,TXT_CSS,TXT_PLAIN,IMG_JPEG,IMG_PNG,APP_OCT_STREAM
};

enum { Z_IMG = 1, Z_TXT, Z_PDF, Z_DOC, Z_XLS, Z_PPT, Z_EXE, Z_VIDEO, Z_MUSIC,
	Z_DATA, Z_FOLDER, Z_ZIP, Z_UNKNOWN };

struct dir_entry{
	char name[200];
	int	 is_file;
};

struct http_data{
	SOCKET sck;
	char *file;
	char keep_alive;
	char data[4096];
	char *user_agent;
	unsigned long ptr;
};

struct http_answer{
	char *data;
	int  status;
	int  content_type;
	long size;
};

struct ext_db{
	char	*ext;
	int		value;
};

struct inzervit{
	char *name;
	char *ptr;
	int  length;
	int  type;	
};

/* Functions */
int initialize_net();
int create_thread(SOCKET *, void *);
void ops_error(char *);
void ops_wait(char *);
void ops_debug(char *,...);
void http_error(struct http_answer *answ, struct http_data *msgs);
void http_list_dir(struct http_answer *answ, struct http_data *msgs);
void http_send_head(struct http_answer *answ, struct http_data *msgs);
void http_parse_hex(char *str);
long get_file_size(char *file);
char *get_word(struct http_data *msgs);
char *get_line(struct http_data *msgs);
int  get_extension(char *file);
void goto_newline(struct http_data *msgs);
void bck_file(char *str);
char *l_strip(char *str,char *what);
char *r_strip(char *str,char *what);
void find_first(struct http_data *msgs);
char *str_toupper(char *str);
char *str_tolower(char *str);

void destroy_http_data(struct http_data *msgs);
//extern zoptions_t zopts;

#endif 
