/*
    This file is part of Zervit
    Copyright (C) 2009  Sebastian Fernandez

    Zervit is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Zervit is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef CONFIG_H_
#define CONFIG_H_

//Scons automatically this when passed "debug=1" option
//If not set, try by hand:
//!!!!!!!!!!!!!!!
//#define Z_DEBUG
//!!!!!!!!!!!!!!!

#ifdef _WIN32
	#define ZERVIT_NAME "zervit.exe"
#elif defined(linux)
	#define ZERVIT_NAME "zervit"
#endif
/*
//Windows includes
#ifdef _WIN32
#include <windows.h>

//Linux includes
#elif defined(linux)
#include <stdlib.h>
#include <unistd.h>
#include <dirent.h>

#endif

//For everybody includes
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <stdarg.h>
*/

#define MAX_DIR_LIST	200
#define MAX_CONNECTIONS 10
#define DEFAULT_PORT    80
#define ZERVIT_VERSION	"Zervit 0.4"

#define ZERVIT_FOOT	"<a href=\"http://zervit.sourceforge.net\">"\
	"<address>"ZERVIT_VERSION" - Portable http server made easy.</address></a>"

#endif /* CONFIG_H_ */
